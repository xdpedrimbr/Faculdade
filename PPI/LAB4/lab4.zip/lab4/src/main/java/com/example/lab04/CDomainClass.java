package com.example.lab04;

public class CDomainClass {
	private String produto;
	private int codigo;
	private String marca;
	private String tipo;
	
	public String getProduto() {
		return produto;
	}
	public void setProduto(String produto) {
		this.produto = produto;
	}
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
	@Override
	public String toString() {
		return "CDomainClass [produto=" + produto + ", codigo=" + codigo + ", marca=" + marca + ", tipo=" + tipo + "]";
	}
	
	
	
}
