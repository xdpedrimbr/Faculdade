package com.example.demo;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class CDomainClass {
	private Long id;
	@NotNull
	@Size(min=3, max=30) 
	private String name;  
	private String cpf;

	public CDomainClass() {}; 
  
	public CDomainClass(String name, String cpf) { 
		this.name = name;
		this.cpf = cpf;
	}; 
	
	public Long getId() { 
		return id;    
	} 
	
	public void setId(Long id) { 
		this.id = id;    
	}  
	
	public String getName() { 
		return name;    
	} 
	
	public void setName(String name) { 
		this.name = name;    
	} 

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	@Override
	public String toString() {
		return "CDomainClass [id=" + id + ", name=" + name + ", cpf=" + cpf + "]";
	}

	
}
